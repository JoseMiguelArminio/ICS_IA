import React from 'react';

export default function EmptyState() {
  return (
    <div className="alert alert-info text-center">
      No se encontraron artículos con los filtros seleccionados.
    </div>
  );
}
