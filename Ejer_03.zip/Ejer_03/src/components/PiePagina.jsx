import React from 'react';

export default function PiePagina() {
  return (
    <footer className="bg-success text-white py-3 mt-auto">
      <div className="container text-center">
        <small>© 2025 Naturaleza Viva - Todos los derechos reservados</small>
      </div>
    </footer>
  );
}
