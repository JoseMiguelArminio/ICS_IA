export const productos = [
  {
    id: 1,
    nombre: 'Teclado Mecánico',
    descripcion: 'Teclado con switches Cherry MX Red.',
    precio: 125.50,
    imagenURL: 'https://lipsum.app/id/1/200x200'
  },
  {
    id: 2,
    nombre: 'Ratón Gaming',
    descripcion: 'Ratón con sensor óptico de 16000 DPI.',
    precio: 75.00,
    imagenURL: 'https://lipsum.app/id/2/200x200'
  },
  {
    id: 3,
    nombre: 'Monitor 27"',
    descripcion: 'Monitor 4K con HDR10 y 144Hz.',
    precio: 350.00,
    imagenURL: 'https://lipsum.app/id/3/200x200'
  }
];
