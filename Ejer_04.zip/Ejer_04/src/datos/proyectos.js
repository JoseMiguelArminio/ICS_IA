export const proyectos = [
  {
    id: 'proj-001',
    titulo: 'Diseño de Landing Page',
    descripcion: 'Crear los mockups y el prototipo visual para la nueva campaña de marketing.',
    estado: 'Pendiente',
    responsables: [{ id: 'u1', nombre: 'Ana Martínez' }],
    prioridad: 'Media'
  },
  {
    id: 'proj-002',
    titulo: 'Migración a la Nube',
    descripcion: 'Mover todos los servicios del servidor local a la nube antes de fin de mes.',
    estado: 'En Progreso',
    responsables: [{ id: 'u2', nombre: 'Carlos' }, { id: 'u3', nombre: 'Beatriz' }],
    prioridad: 'Alta'
  },
  {
    id: 'proj-003',
    titulo: 'Optimización SEO',
    descripcion: 'Mejorar el posicionamiento en buscadores de la página principal.',
    estado: 'Completado',
    responsables: [{ id: 'u4', nombre: 'Elena Ríos' }, { id: 'u5', nombre: 'Beatriz' }],
    prioridad: 'Baja'
  }
];
